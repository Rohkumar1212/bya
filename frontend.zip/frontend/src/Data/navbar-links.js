export const NavbarLinks = [
  {
    title: "Home",
    path: "/",
  },
    {
      title: "Doctor",
      path: '/doctor',
    },
    {
      title: "Hospital",
      path: "/hospital",
    },
    {
      title: "Lab Tests",
      path: "/labtest",
    },
  ];
  
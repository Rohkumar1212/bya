import React from 'react'

const Banner = () => {
  return (
    <div
        className="  relative mx-auto flex max-w-maxContent flex-col 
    items-center  font-mont  text-white h-24 w-full  bg-richblack-100 "
      >
<h1 className='text-xl font-bold text-black'>Banner Here</h1>
      </div>
  )
}

export default Banner
